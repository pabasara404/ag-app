<template>
    <v-layout class="rounded rounded-md">
        <v-app-bar title="Sample App" class="flex justify-between" color="teal-darken-4">
            <template v-slot:image>
                <v-img
                    gradient="to top right, rgba(19,84,122,.8), rgba(128,208,199,.8)"
                ></v-img>
            </template>
            <v-btn variant="outlined" @click="handleLogout">
                Logout
            </v-btn>
        </v-app-bar>

        <v-navigation-drawer>
            <v-list
                :lines="false"
                density="compact"
                nav
            >
                <v-list-item
                    v-for="(item, i) in sideBarItems"
                    :key="i"
                    :value="item"
                    color="primary"
                    :to="item.path"
                >
                    <template v-slot:prepend>
                        <v-icon :icon="item.icon"></v-icon>
                    </template>
                    <v-list-item-title v-text="item.text"></v-list-item-title>
                </v-list-item>
            </v-list>
        </v-navigation-drawer>

        <v-main class="d-flex align-start justify-center" style="min-height: 300px;">
            <router-view/>
        </v-main>
    </v-layout>
</template>

<script setup>
import {useRouter} from "vue-router";
import {onMounted} from "vue";

const router = useRouter()
const sideBarItems = [
    { text: 'Dashboard', icon: 'mdi-home', path: '/dashboard' },
    { text: 'Programmes', icon: 'mdi-account-multiple', path: '/programmes' },
    { text: 'Starred', icon: 'mdi-star' },
    { text: 'Recent', icon: 'mdi-history' },
    { text: 'Offline', icon: 'mdi-check-circle' },
    { text: 'Uploads', icon: 'mdi-upload' },
    { text: 'Backups', icon: 'mdi-cloud-upload' },
]

onMounted(async () => {
    const response = await axios.get('api/user')
    console.log(response)
})

const handleLogout = () => {
    localStorage.removeItem('APP_DEMO_USER_TOKEN')
    router.push('/')
}
</script>

<style scoped>

</style>
